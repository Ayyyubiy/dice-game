let randomNumber = Math.floor(Math.random() * 6) + 1;

let randomImages = "dice" + randomNumber + ".png";

let randomImagesSource = "images/" + randomImages;

let images = document
  .querySelectorAll("img")[0]
  .setAttribute("src", randomImagesSource);

let randomNumber2 = Math.floor(Math.random() * 6) + 1;

let randomImages2 = "dice" + randomNumber2 + ".png";

let randomImagesSource2 = "images/" + randomImages2;

let images2 = document
  .querySelectorAll("img")[1]
  .setAttribute("src", randomImagesSource2);
